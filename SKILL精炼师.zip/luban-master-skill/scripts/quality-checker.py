#!/usr/bin/env python3
"""
鲁班大师 - Skill质量检查器
五维质量评估体系
"""

import os
import re
from pathlib import Path
from typing import Dict, List

class QualityChecker:
    """Skill质量评估器"""
    
    def __init__(self, skill_path: str):
        self.skill_path = Path(skill_path)
        self.scores = {}
        self.total_score = 0
    
    def check_structure_integrity(self) -> Dict:
        """结构完整性检查 (25分)"""
        score = 25
        issues = []
        
        required_files = ['SKILL.md']
        required_dirs = ['scripts', 'references', 'assets']
        
        for f in required_files:
            if not (self.skill_path / f).exists():
                score -= 8
                issues.append(f"缺少必需文件: {f}")
        
        for d in required_dirs:
            if not (self.skill_path / d).exists():
                score -= 5
                issues.append(f"缺少标准目录: {d}")
        
        return {"score": max(0, score), "max_score": 25, "issues": issues}
    
    def check_documentation(self) -> Dict:
        """文档规范性检查 (20分)"""
        score = 20
        issues = []
        
        skill_md = self.skill_path / 'SKILL.md'
        if skill_md.exists():
            with open(skill_md, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # 检查frontmatter
            if not re.match(r'^---\n.*?\n---', content, re.DOTALL):
                score -= 5
                issues.append("缺少frontmatter")
            
            # 检查章节完整性
            required_sections = ['概述', '使用', '功能']
            for section in required_sections:
                if section not in content:
                    score -= 3
                    issues.append(f"建议添加章节: {section}")
            
            # 检查示例
            if '```' not in content:
                score -= 4
                issues.append("缺少代码/使用示例")
        else:
            score = 0
            issues.append("SKILL.md不存在")
        
        return {"score": max(0, score), "max_score": 20, "issues": issues}
    
    def check_code_quality(self) -> Dict:
        """代码质量检查 (25分)"""
        score = 25
        issues = []
        
        scripts_dir = self.skill_path / 'scripts'
        if scripts_dir.exists():
            py_files = list(scripts_dir.glob('*.py'))
            if py_files:
                for py_file in py_files:
                    with open(py_file, 'r', encoding='utf-8') as f:
                        content = f.read()
                    
                    # 错误处理
                    if 'try:' not in content:
                        score -= 5
                        issues.append(f"{py_file.name}: 缺少错误处理")
                        break
                    
                    # 类型注解
                    if '->' not in content:
                        score -= 4
                        issues.append(f"{py_file.name}: 缺少类型注解")
                        break
                    
                    # 注释
                    if '"""' not in content and "'''" not in content:
                        score -= 3
                        issues.append(f"{py_file.name}: 缺少文档字符串")
                        break
            else:
                score -= 10
                issues.append("scripts目录下无Python脚本")
        else:
            score -= 15
            issues.append("scripts目录不存在")
        
        return {"score": max(0, score), "max_score": 25, "issues": issues}
    
    def check_function_completeness(self) -> Dict:
        """功能完备性检查 (20分)"""
        score = 20
        issues = []
        
        # 检查是否有可运行入口
        scripts_dir = self.skill_path / 'scripts'
        has_main = False
        if scripts_dir.exists():
            for py_file in scripts_dir.glob('*.py'):
                with open(py_file, 'r', encoding='utf-8') as f:
                    if "__main__" in f.read():
                        has_main = True
                        break
        
        if not has_main:
            score -= 8
            issues.append("缺少可运行的主函数入口")
        
        # 检查配置灵活性
        skill_md = self.skill_path / 'SKILL.md'
        if skill_md.exists():
            with open(skill_md, 'r', encoding='utf-8') as f:
                if '参数' not in f.read() and '配置' not in f.read():
                    score -= 6
                    issues.append("缺少参数/配置说明")
        
        return {"score": max(0, score), "max_score": 20, "issues": issues}
    
    def check_user_experience(self) -> Dict:
        """用户体验检查 (10分)"""
        score = 10
        issues = []
        
        skill_md = self.skill_path / 'SKILL.md'
        if skill_md.exists():
            with open(skill_md, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # 快速开始
            if '快速开始' not in content and '使用方法' not in content:
                score -= 4
                issues.append("缺少快速开始/使用方法")
            
            # 常见问题
            if 'FAQ' not in content and '常见问题' not in content:
                score -= 3
                issues.append("建议添加常见问题FAQ")
        
        return {"score": max(0, score), "max_score": 10, "issues": issues}
    
    def evaluate(self) -> Dict:
        """执行完整评估"""
        results = {
            "结构完整性": self.check_structure_integrity(),
            "文档规范性": self.check_documentation(),
            "代码质量": self.check_code_quality(),
            "功能完备性": self.check_function_completeness(),
            "用户体验": self.check_user_experience(),
        }
        
        total = sum(r['score'] for r in results.values())
        max_total = sum(r['max_score'] for r in results.values())
        
        all_issues = []
        for name, result in results.items():
            for issue in result['issues']:
                all_issues.append(f"[{name}] {issue}")
        
        return {
            "scores": results,
            "total_score": total,
            "max_score": max_total,
            "percentage": round(total / max_total * 100, 1),
            "all_issues": all_issues
        }
    
    def print_report(self):
        """打印评估报告"""
        result = self.evaluate()
        
        print("=" * 60)
        print("🛠️  鲁班大师 - Skill质量评估报告")
        print("=" * 60)
        print(f"\n📊 综合评分: {result['total_score']}/{result['max_score']} ({result['percentage']}%)")
        print()
        
        for name, data in result['scores'].items():
            bar = "█" * int(data['score'] / data['max_score'] * 20)
            print(f"  {name:12s} | {bar:20s} | {data['score']:2d}/{data['max_score']}")
        
        print("\n" + "=" * 60)
        print("🔍 发现的问题:")
        for issue in result['all_issues']:
            print(f"  - {issue}")
        print("=" * 60)

if __name__ == "__main__":
    checker = QualityChecker(".")
    checker.print_report()
