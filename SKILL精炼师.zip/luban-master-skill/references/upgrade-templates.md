# Skill升级模板库

## 标准Skill结构模板

### 1. 基础Skill结构模板
```
skill-name/
├── SKILL.md              # 主说明文档（必需）
├── scripts/              # 脚本目录
│   ├── main.py          # 主执行脚本
│   └── utils.py         # 工具函数
├── references/           # 参考资料目录
│   ├── database.md      # 数据库/知识库
│   └── examples.md      # 使用示例
├── assets/               # 资源目录
│   ├── images/          # 图片资源
│   └── templates/       # 模板文件
└── README.md            # 额外说明（可选）
```

### 2. SKILL.md frontmatter标准模板
```yaml
---
name: skill-name
description: 一句话清晰描述Skill功能
author: 作者名
version: 1.0.0
created: YYYY-MM-DD
updated: YYYY-MM-DD
license: MIT
requirements:
  - python >= 3.8
  - 其他依赖
tags:
  - 标签1
  - 标签2
---
```

### 3. Python脚本标准模板
```python
#!/usr/bin/env python3
"""
模块功能说明
@author: 作者
@version: 1.0.0
"""

import os
import sys
import logging
from typing import Optional, Dict, List

# 日志配置
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class SkillClassName:
    """主类说明"""
    
    def __init__(self, config: Optional[Dict] = None):
        """初始化"""
        self.config = config or {}
        self._validate_config()
    
    def _validate_config(self) -> None:
        """配置验证"""
        pass
    
    def run(self, input_data: Dict) -> Dict:
        """主执行函数"""
        try:
            result = self._process(input_data)
            return {"status": "success", "data": result}
        except Exception as e:
            logger.error(f"执行失败: {str(e)}")
            return {"status": "error", "message": str(e)}
    
    def _process(self, input_data: Dict) -> Dict:
        """核心处理逻辑"""
        raise NotImplementedError

if __name__ == "__main__":
    # 示例运行
    skill = SkillClassName()
    result = skill.run({"test": "data"})
    print(result)
```

## 常见问题修复模板

### 1. 缺少错误处理
**问题代码**：
```python
def process(data):
    return data['key']  # KeyError风险
```

**修复后**：
```python
def process(data):
    try:
        return data.get('key', 'default_value')
    except Exception as e:
        logger.warning(f"获取key失败: {e}")
        return 'default_value'
```

### 2. 缺少类型注解
**问题代码**：
```python
def calculate(x, y):
    return x + y
```

**修复后**：
```python
def calculate(x: float, y: float) -> float:
    """计算两数之和"""
    return x + y
```

### 3. 硬编码路径
**问题代码**：
```python
with open('/home/user/data.txt') as f:
    data = f.read()
```

**修复后**：
```python
import os
data_path = os.path.join(os.path.dirname(__file__), '..', 'data', 'data.txt')
with open(data_path, 'r', encoding='utf-8') as f:
    data = f.read()
```

## 文档完善模板

### 1. 使用说明标准章节
```
## 使用方法
### 前置条件
- 环境要求
- 依赖安装
- 配置说明

### 快速开始
```bash
# 安装依赖
pip install -r requirements.txt

# 运行示例
python scripts/main.py
```

### 参数说明
| 参数名 | 类型 | 必填 | 默认值 | 说明 |
|--------|------|------|--------|------|
| param1 | str | 是 | - | 参数说明 |

### 输出示例
```json
{
  "key": "value"
}
```
```

### 2. 常见问题FAQ模板
```
## 常见问题

### Q: 遇到XX错误怎么办？
A: 这通常是因为XX原因，请按以下步骤解决：
1. 步骤1
2. 步骤2

### Q: 如何配置XX功能？
A: 参考配置文件config.yaml中的XX字段...
```

## 版本号规范

采用语义化版本号：`主版本.次版本.修订号`
- **主版本**：不兼容的API变更
- **次版本**：向下兼容的功能性新增
- **修订号**：向下兼容的问题修正

示例：
- v1.0.0 → 首个正式版本
- v1.0.1 → 修复bug
- v1.1.0 → 新增功能
- v2.0.0 → 重大重构
