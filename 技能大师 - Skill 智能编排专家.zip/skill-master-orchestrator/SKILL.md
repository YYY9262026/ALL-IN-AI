---
name: skill-master-orchestrator
description: 技能大师 - AI Skill智能编排与协作专家。基于Claude Agent Skills深度优化，专注于多Skill协同工作流编排、技能组合策略、复杂任务分解与执行调度。让多个AI技能像专业团队一样无缝协作。
version: 2.0.0
author: 鲁班大师工作室
license: MIT
tags: [skill-orchestration, agent-collaboration, workflow, task-decomposition]
---

# 技能大师 - Skill智能编排与协作专家

## 概述
本Skill基于GitHub热门项目 **Claude Agent Skills (60.9K+ Stars)** 深度优化重构。原版专注于单Skill执行，本版本升级为**多Skill智能编排引擎**，解决复杂任务下的技能组合、调度、协同问题。

**核心优化升级**：
- ✅ 新增**工作流编排引擎**（原版无此功能）
- ✅ 新增**技能依赖关系管理**
- ✅ 新增**并行/串行执行调度**
- ✅ 新增**错误重试与降级策略**
- ✅ 新增**执行结果聚合与汇总**

## 核心功能

### 1. 智能任务分解
将复杂用户需求自动拆解为可执行的子任务：
```
用户需求 → 任务分析 → 技能匹配 → 执行计划生成
```

### 2. 多Skill编排策略
**执行模式**：
- 🔹 **串行模式**：按顺序执行，前一个输出作为后一个输入
- 🔹 **并行模式**：多技能同时执行，结果汇总
- 🔹 **条件分支**：根据中间结果选择执行路径
- 🔹 **循环模式**：满足条件前重复执行

### 3. 技能依赖管理
- 自动识别技能间输入输出依赖
- 构建有向无环图(DAG)执行计划
- 循环依赖检测与告警
- 按需加载与资源优化

### 4. 容错与降级机制
- 单技能失败不影响整体流程
- 自动重试策略配置
- 降级方案自动切换
- 断点续执行支持

## 典型编排场景

### 🎯 场景1：内容创作流水线
```
[需求分析] → [大纲生成] → [正文撰写] → [润色优化] → [格式排版]
     ↓           ↓            ↓            ↓            ↓
  理解Skill   结构Skill   写作Skill   编辑Skill   排版Skill
```

### 🎯 场景2：数据分析工作流
```
          ┌→ [数据清洗] ─┐
[数据获取] ┼→ [特征提取] ─┼→ [模型训练] → [结果可视化]
          └→ [统计分析] ─┘
    (并行执行三个预处理技能)
```

### 🎯 场景3：客户服务响应
```
[意图识别]
     ↓
┌─ 咨询类 → [知识库检索] → [答案生成]
├─ 投诉类 → [情绪分析] → [人工转接]
└─ 下单类 → [订单校验] → [支付处理]
```

## 编排配置示例

```yaml
workflow:
  name: "内容创作流水线"
  version: "1.0"
  
  skills:
    - name: requirement-analyzer
      input: user_query
      output: requirement_spec
      
    - name: outline-generator
      input: requirement_spec
      output: content_outline
      depends_on: [requirement-analyzer]
      
    - name: content-writer
      input: content_outline
      output: draft_content
      depends_on: [outline-generator]
      
    - name: content-editor
      input: draft_content
      output: final_content
      depends_on: [content-writer]
  
  execution:
    mode: sequential
    retry_count: 2
    timeout_seconds: 300
```

## 资源引用
- **编排模板库**：`references/workflow-templates.md`
- **执行引擎**：`scripts/orchestrator-engine.py`
- **可视化工具**：`scripts/workflow-visualizer.py`

## 性能指标
| 指标 | 目标值 |
|------|--------|
| 单工作流最大技能数 | 50个 |
| 并行执行最大并发 | 20个 |
| 编排解析耗时 | < 100ms |
| 任务成功率 | 99.5%+ |

---
**技能大师 - 让AI技能协同如行云流水**
